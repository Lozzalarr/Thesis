# Flight2 > 2023-06-22 5:00pm
https://universe.roboflow.com/thesis-4lykz/flight2

Provided by a Roboflow user
License: CC BY 4.0

