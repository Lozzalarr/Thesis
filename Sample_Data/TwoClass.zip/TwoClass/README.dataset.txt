# Flight2 > OneClass-x3
https://universe.roboflow.com/thesis-4lykz/flight2

Provided by a Roboflow user
License: CC BY 4.0

